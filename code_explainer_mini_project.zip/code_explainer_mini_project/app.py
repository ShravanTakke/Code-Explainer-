import os
import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(page_title="Code Explainer", page_icon="🧠", layout="wide")

st.markdown('''
<style>
.block-container {padding-top: 2rem; max-width: 1250px;}
.hero {padding: 1.4rem 1.6rem; border: 1px solid #293653; border-radius: 18px;
       background: linear-gradient(120deg,#172443,#10182b); margin-bottom: 1.2rem;}
.hero h1 {margin: 0; color: #f4f7ff;}
.hero p {color: #bdc9e2; margin: .45rem 0 0 0;}
div[data-testid="stTextArea"] textarea {font-family: monospace;}
</style>
<div class="hero">
  <h1>🧠 Code Explainer</h1>
  <p>Paste code. Get a simple overview and a line-by-line explanation.</p>
</div>
''', unsafe_allow_html=True)

def get_api_key():
    try:
        return st.secrets.get("GEMINI_API_KEY", "") or os.getenv("GEMINI_API_KEY", "")
    except Exception:
        return os.getenv("GEMINI_API_KEY", "")

languages = ["Python", "Java", "C", "C++", "JavaScript", "HTML/CSS", "SQL", "C#", "PHP", "Go", "Rust", "Other"]

left, right = st.columns([1, 1], gap="large")
with left:
    st.subheader("1. Your code")
    language = st.selectbox("Programming language", languages)
    code = st.text_area("Paste your code here", height=390, placeholder='# Example: Python\nname = "Alex"\nfor i in range(3):\n    print("Hello", name)')
    explain_button = st.button("✨ Explain my code", type="primary", use_container_width=True)

with right:
    st.subheader("2. Explanation")
    if explain_button:
        if not code.strip():
            st.warning("Paste some code first.")
        else:
            api_key = get_api_key()
            if not api_key:
                st.error("Gemini API key not found. Add GEMINI_API_KEY to your environment or Streamlit secrets. See README.md.")
            else:
                prompt = (
                    "You are a friendly programming teacher explaining code to a beginner.\n"
                    f"Language: {language}\n\n"
                    "Explain the code below accurately. Do not execute it or invent behavior. "
                    "Use these sections: Overview; Line-by-line explanation (refer to line numbers); "
                    "Important concepts; Possible improvements. Keep it beginner-friendly.\n\n"
                    f"CODE:\n```{language.lower()}\n{code}\n```"
                )
                try:
                    with st.spinner("Preparing your explanation..."):
                        client = genai.Client(api_key=api_key)
                        response = client.models.generate_content(
                            model="gemini-3.8-flash",
                            contents=prompt,
                            config=types.GenerateContentConfig(temperature=0.2)
                        )
                    st.markdown(response.text or "The model returned an empty response.")
                except Exception as e:
                    st.error(f"Could not generate the explanation: {e}")
    else:
        st.info("Your explanation will appear here.")
        st.markdown("**The app provides:**\n- A short code overview\n- Line-by-line explanations\n- Definitions of important concepts\n- Suggestions for improvement")

st.divider()
st.caption("Mini Project • Code Explainer • Built with Python, Streamlit and Gemini")
